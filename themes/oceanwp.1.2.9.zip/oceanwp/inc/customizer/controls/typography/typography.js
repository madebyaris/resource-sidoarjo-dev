( function($) {

	$( document ).ready(function () {

		$( '.oceanwp-typography-select' ).oceanwpSelect2();

	} );

} )( jQuery );
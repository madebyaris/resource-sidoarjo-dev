<div class="skt-header-image">
	<!-- header image -->
	<div class="eptima-lite-front-bgimg"><img alt="<?php _e('Background Image','eptima-lite'); ?>" class="ad-slider-image" width="1585"  src="<?php if( get_header_image() ) { header_image(); } else { echo get_template_directory_uri().'/images/slider-image.png'; } ?>" ></div>
</div>
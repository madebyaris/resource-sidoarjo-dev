<?php
/********************************************
 FRAME WORK CODE STARTS HERE
*********************************************/
require_once(get_template_directory().'/SketchBoard/functions/eptima-functions.php');               	 		// PAGINATION, EXCERPT CONTROL ETC.
require_once(get_template_directory().'/SketchBoard/functions/eptima-enqueue.php');                  			// ENQUEUE CSS SCRIPTS
require_once(get_template_directory().'/SketchBoard/functions/eptima-breadcrumb.php');               			// INCLUDE BREADCRUMB
?>